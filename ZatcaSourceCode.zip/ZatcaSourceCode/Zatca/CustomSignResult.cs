﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Zatca.EInvoice.SDK.Contracts.Models;

namespace Zatca
{
    public class CustomSignResult
    {
        public bool IsValid { get; set; }
        public string ErrorMessage { get; set; }
        public XmlDocument SignedEInvoice { get; set; }
        public string SignedEInvoiceBase64 { get; set; }
        public List<StepResult> Steps { get; set; } = new List<StepResult>();

    }
}
