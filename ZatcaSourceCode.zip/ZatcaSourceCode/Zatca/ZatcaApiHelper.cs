﻿using System;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Xml;
using Zatca.EInvoice.SDK.Contracts.Models;
using Zatca.EInvoice.SDK;
using Newtonsoft.Json;
using System.IO;
using javax.xml.transform;
using System.Xml.Linq;
using Org.BouncyCastle.Utilities.Encoders;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Collections.Generic;

namespace Zatca
{
    public class ZatcaApiHelper
    {
        public string ComplianceCSIDApi(string BaseURL, string Apiendpoint, string OTP, string CSR)
        {
            using (HttpClient client = new HttpClient())
            {

                client.BaseAddress = (new Uri(BaseURL));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("OTP", OTP);
                client.DefaultRequestHeaders.Add("Accept-Version", "V2");
                StringContent content = new StringContent(CSR, Encoding.UTF8, "application/json");
                HttpResponseMessage result = client.PostAsync(Apiendpoint, content).Result;
                string str2 = result.Content.ReadAsStringAsync().Result;
                //if (result.IsSuccessStatusCode)
                //{
                //    //companyInfo = JsonConvert.DeserializeObject<CompanyInfo>(str2);
                //}

                return str2;
            }
        }
        public string ProductionCSID_OnboardApi(string BaseURL, string Apiendpoint, string binarySecurityToken, string secret, string requestbody)
        {
            string username = binarySecurityToken;
            string password = secret;

            string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));

            using (HttpClient client = new HttpClient())
            {

                client.BaseAddress = (new Uri(BaseURL));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + svcCredentials);
                client.DefaultRequestHeaders.Add("Accept-Version", "V2");
                StringContent content = new StringContent(requestbody, Encoding.UTF8, "application/json");
                HttpResponseMessage result = client.PostAsync(Apiendpoint, content).Result;
                string str2 = result.Content.ReadAsStringAsync().Result;
                //if (result.IsSuccessStatusCode)
                //{
                //    string str2 = result.Content.ReadAsStringAsync().Result;
                //    return str2;
                //    //companyInfo = JsonConvert.DeserializeObject<CompanyInfo>(str2);
                //}
                return str2;

            }
        }
        public string ProductionCSID_RenewalApi(string BaseURL, string Apiendpoint, string OTP, string language, string binarySecurityToken, string secret, string CSR)
        {
            string username = binarySecurityToken;
            string password = secret;

            string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));

            using (HttpClient client = new HttpClient())
            {

                client.BaseAddress = (new Uri(BaseURL));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + svcCredentials);
                client.DefaultRequestHeaders.Add("OTP", OTP);
                client.DefaultRequestHeaders.Add("Accept-Version", "V2");
                client.DefaultRequestHeaders.Add("accept-language", language);
                StringContent content = new StringContent(CSR, Encoding.UTF8, "application/json");
                var request = new HttpRequestMessage(new HttpMethod("PATCH"), Apiendpoint)
                {
                    Content = content
                };
                HttpResponseMessage result = client.SendAsync(request).Result;
                string str2 = result.Content.ReadAsStringAsync().Result;
                //if (result.IsSuccessStatusCode)
                //{
                //    string str2 = result.Content.ReadAsStringAsync().Result;
                //    return str2;
                //    //companyInfo = JsonConvert.DeserializeObject<CompanyInfo>(str2);
                //}
                return str2;

            }
        }
        //public string ClearanceApi(string BaseURL, string Apiendpoint, string language, string Clearance_Status, string binarySecurityToken, string secret, string requestbody)
        //{
        //    string username = binarySecurityToken;
        //    string password = secret;

        //    string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));

        //    using (HttpClient client = new HttpClient())
        //    {

        //        client.BaseAddress = (new Uri(BaseURL));
        //        client.DefaultRequestHeaders.Accept.Clear();
        //        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        //        client.DefaultRequestHeaders.Add("Authorization", "Basic " + svcCredentials);
        //        client.DefaultRequestHeaders.Add("Accept-Version", "V2");
        //        client.DefaultRequestHeaders.Add("accept-language", language);
        //        client.DefaultRequestHeaders.Add("Clearance-Status", Clearance_Status);
        //        StringContent content = new StringContent(requestbody, Encoding.UTF8, "application/json");
        //        HttpResponseMessage result = client.PostAsync(Apiendpoint, content).Result;
        //        string str2 = result.Content.ReadAsStringAsync().Result;
        //        //if (result.IsSuccessStatusCode)
        //        //{
        //        //    string str2 = result.Content.ReadAsStringAsync().Result;
        //        //    return str2;
        //        //    //companyInfo = JsonConvert.DeserializeObject<CompanyInfo>(str2);
        //        //}
        //        return str2;

        //    }
        //}
        public string ClearanceApi(string BaseURL, string Apiendpoint, string language, string Clearance_Status, string ProdBinarySecurityToken, string ProdSecret, string CompCSID, string csrPrivatekey, XmlDocument xml, string UUID)
        {
            CustomSignResult signresult = new CustomSignResult();
            string encryptedjson = "";
            string requestbody = "";
            string username = ProdBinarySecurityToken;
            string password = ProdSecret;
            string authCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));

            // encrypt Invoice
            encryptedjson = EncryptInvoice(CompCSID, csrPrivatekey, xml);
            signresult = JsonConvert.DeserializeObject<CustomSignResult>(encryptedjson);
            if (!signresult.IsValid)
            {

                EncryptionResult encryptionresult = new EncryptionResult();
                encryptionresult.ErrorMessage = signresult.ErrorMessage;
                encryptionresult.Steps = signresult.Steps;
                ClearenceResponse clearenceresponse = new ClearenceResponse();
                clearenceresponse.IsValid = false;
                clearenceresponse.encryptionResults = encryptionresult;
                return JsonConvert.SerializeObject(clearenceresponse);
            }
            string signedXmlBase64 = signresult.SignedEInvoiceBase64;
            // encrypt Invoice

            //Generate Request body
            ReportRequestBody reportrequestbody = new ReportRequestBody();
            reportrequestbody.invoiceHash = signresult.Steps.Where(m => m.StepName == "Generate EInvoice Hash").FirstOrDefault().ResultedValue;
            reportrequestbody.uuid = UUID;
            reportrequestbody.invoice = signedXmlBase64;
            requestbody = JsonConvert.SerializeObject(reportrequestbody);
            //Generate Request body

            using (HttpClient client = new HttpClient())
            {

                client.BaseAddress = (new Uri(BaseURL));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + authCredentials);
                client.DefaultRequestHeaders.Add("Accept-Version", "V2");
                client.DefaultRequestHeaders.Add("accept-language", language);
                client.DefaultRequestHeaders.Add("Clearance-Status", Clearance_Status);
                StringContent content = new StringContent(requestbody, Encoding.UTF8, "application/json");
                HttpResponseMessage result = client.PostAsync(Apiendpoint, content).Result;
                string str2 = result.Content.ReadAsStringAsync().Result;
                if (result.IsSuccessStatusCode)
                {
                    var clearenceresponse = JsonConvert.DeserializeObject<ClearenceResponse>(str2);
                    clearenceresponse.IsValid = true;
                    clearenceresponse.QR = GetQRcode(clearenceresponse.clearedInvoice);
                    return JsonConvert.SerializeObject(clearenceresponse);
                }

                return str2;

            }
        }
        public string ClearanceApiusingBase64Xml(string BaseURL, string Apiendpoint, string language, string Clearance_Status, string ProdBinarySecurityToken, string ProdSecret, string CompCSID, string csrPrivatekey, string xmlbase64, string UUID)
        {
            XDocument parsedoc = XDocument.Parse(Encoding.UTF8.GetString(System.Convert.FromBase64String(xmlbase64)));
            XmlDocument doc = new XmlDocument();
            doc.PreserveWhitespace = true;
            var strms = @"<?xml version=""1.0"" encoding=""utf-8""?>
" + parsedoc.ToString();

            doc.LoadXml(strms);

            return ClearanceApi(BaseURL, Apiendpoint, language,
                Clearance_Status, ProdBinarySecurityToken, ProdSecret, CompCSID, csrPrivatekey, doc, UUID);
        }
        public string ClearanceApiusingStringXml(string BaseURL, string Apiendpoint, string language, string Clearance_Status, string ProdBinarySecurityToken, string ProdSecret, string CompCSID, string csrPrivatekey, string xml, string UUID)
        {
            //XDocument parsedoc = XDocument.Parse(xml);
            XmlDocument doc = new XmlDocument();
            doc.PreserveWhitespace = true;
            //            var strms = @"<?xml version=""1.0"" encoding=""utf-8""?>
            //" + parsedoc.ToString();

            doc.LoadXml(xml);

            return ClearanceApi(BaseURL, Apiendpoint, language,
                Clearance_Status, ProdBinarySecurityToken, ProdSecret, CompCSID, csrPrivatekey, doc, UUID);
        }
        public string ReportingApi(string BaseURL, string Apiendpoint, string language, string Clearance_Status, string binarySecurityToken, string secret, string requestbody)
        {
            string username = binarySecurityToken;
            string password = secret;
            string authCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));

            using (HttpClient client = new HttpClient())
            {

                client.BaseAddress = (new Uri(BaseURL));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + authCredentials);
                client.DefaultRequestHeaders.Add("Accept-Version", "V2");
                client.DefaultRequestHeaders.Add("accept-language", language);
                client.DefaultRequestHeaders.Add("Clearance-Status", Clearance_Status);
                StringContent content = new StringContent(requestbody, Encoding.UTF8, "application/json");
                HttpResponseMessage result = client.PostAsync(Apiendpoint, content).Result;
                string str2 = result.Content.ReadAsStringAsync().Result;
                //if (result.IsSuccessStatusCode)
                //{
                //    string str2 = result.Content.ReadAsStringAsync().Result;
                //    return str2;
                //    //companyInfo = JsonConvert.DeserializeObject<CompanyInfo>(str2);
                //}
                return str2;

            }
        }
        public string EncryptInvoice(string CompCSID, string csrPrivatekey, XmlDocument xml)
        {
            CustomSignResult customSignResult = new CustomSignResult();
            SignResult result = new SignResult();
            try
            {
                xml.PreserveWhitespace = true;
                EInvoiceSigner EiS = new EInvoiceSigner();
                CompCSID = Encoding.UTF8.GetString(System.Convert.FromBase64String(CompCSID));
                result = EiS.SignDocument(xml, CompCSID, csrPrivatekey);
                customSignResult.ErrorMessage = result.ErrorMessage;
                customSignResult.IsValid = result.IsValid;
                customSignResult.Steps = result.Steps;
                customSignResult.SignedEInvoice = result.SignedEInvoice;

                string signedXml;
                using (var stringWriter = new StringWriter())
                using (var xmlTextWriter = XmlWriter.Create(stringWriter))
                {
                    result.SignedEInvoice.WriteTo(xmlTextWriter);
                    xmlTextWriter.Flush();
                    signedXml = stringWriter.GetStringBuilder().ToString();
                }
                string signedXmlBase64 =
                    Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(signedXml));
                customSignResult.SignedEInvoiceBase64 = signedXmlBase64;

            }
            catch (Exception ex)
            {
                customSignResult.ErrorMessage = ex.Message;
            }
            return JsonConvert.SerializeObject(customSignResult);
        }
        public string GenerateCSR(string commonName, string serialNumber, string organizationIdentifier, string organizationUnitName, string organizationName, string countryName, string invoiceType, string locationAddress, string industryBusinessCategory, string environmentType)
        {
            CsrResult csrResult = new CsrResult();
            CsrGenerator csr = new CsrGenerator();
            CsrGenerationDto dto = new CsrGenerationDto(commonName, serialNumber, organizationIdentifier, organizationUnitName, organizationName, countryName, invoiceType, locationAddress, industryBusinessCategory);

            if (string.IsNullOrEmpty(environmentType))
            {
                csrResult.IsValid = false;
                csrResult.ErrorMessages.Add("environmentType value shuold be production or simulation");
                return JsonConvert.SerializeObject(csrResult);
            }
            if (environmentType.ToLower() != "production" && environmentType.ToLower() != "simulation")
            {
                csrResult.IsValid = false;
                csrResult.ErrorMessages.Add("environmentType value shuold be production or simulation");
                return JsonConvert.SerializeObject(csrResult);
            }
            csrResult = csr.GenerateCsr(dto, environmentType.ToLower() == "production" ? EnvironmentType.Production : EnvironmentType.Simulation, true);
            return JsonConvert.SerializeObject(csrResult);
        }
        public bool GetID(string clearedInvoice)
        {

            // Your XML data
            string xmlData = @"<?xml version=""1.0"" encoding=""UTF-8""?>
            <Invoice xmlns:ext=""urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2"" xmlns:cbc=""urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"" xmlns:cac=""urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"" xmlns=""urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"">
                <cbc:ProfileID>reporting:1.0</cbc:ProfileID>
                <cbc:ID>ECDC-FCN-000010</cbc:ID>
                <cbc:UUID>39E9DBC4-8D4D-41F5-8F83-CE1E66F59B27</cbc:UUID>
                <cbc:IssueDate>2024-05-12</cbc:IssueDate>
                <cbc:IssueTime>12:21:28</cbc:IssueTime>
                <cbc:InvoiceTypeCode name=""0100000"">383</cbc:InvoiceTypeCode>
                <cbc:DocumentCurrencyCode>SAR</cbc:DocumentCurrencyCode>
                <cbc:TaxCurrencyCode>SAR</cbc:TaxCurrencyCode>
                <cac:BillingReference>
                    <cac:InvoiceDocumentReference>
                        <cbc:ID>ECDC-FCN-000010</cbc:ID>
                    </cac:InvoiceDocumentReference>
                </cac:BillingReference>
                <cac:AdditionalDocumentReference>
                    <cbc:ID>ICV</cbc:ID>
                    <cbc:UUID>16</cbc:UUID>
                </cac:AdditionalDocumentReference>
                <cac:AdditionalDocumentReference>
                    <cbc:ID>PIH</cbc:ID>
                </cac:AdditionalDocumentReference>
                <!-- More XML elements -->
            </Invoice>";

            // Load the XML document
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(xmlData);

            // Define the namespace manager to handle the namespaces in the XML
            XmlNamespaceManager namespaceManager = new XmlNamespaceManager(doc.NameTable);
            namespaceManager.AddNamespace("cbc", "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2");
            namespaceManager.AddNamespace("cac", "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2");

            // XPath to select all <cbc:ID> elements in the XML
            XmlNodeList idNodes = doc.SelectNodes("//cbc:ID", namespaceManager);
            List<string> ids = new List<string>();
            // Iterate through the selected nodes and print their values
            foreach (XmlNode idNode in idNodes)
            {
                ids.Add(idNode.InnerText);
            }
            string value = string.Join(",", ids.ToArray()).ToLower();
            if (value.Contains("ecdc") || value.Contains("ecoc"))
            {
                return true;
            }
            return false;
        }
        public string GetQRcode(string clearedInvoice)
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(Encoding.UTF8.GetString(System.Convert.FromBase64String(clearedInvoice)));
                XmlNamespaceManager namespaceManager = new XmlNamespaceManager(xmlDoc.NameTable);
                namespaceManager.AddNamespace("cbc", "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2");
                namespaceManager.AddNamespace("cac", "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2");

                // Select the node containing the QR code value
                XmlNode qrNode = xmlDoc.SelectSingleNode("//cac:AdditionalDocumentReference[cbc:ID='QR']/cac:Attachment/cbc:EmbeddedDocumentBinaryObject", namespaceManager);

                if (qrNode != null)
                {
                    // Return the inner text of the QR node
                    return qrNode.InnerText;
                }
                else
                {
                    // QR node not found
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public string ComplianceCheckApi(string BaseURL, string Apiendpoint, string language, string ProdBinarySecurityToken, string ProdSecret, string CompCSID, string csrPrivatekey, string xml, string UUID)
        {
            XmlDocument doc = new XmlDocument();
            doc.PreserveWhitespace = true;
            doc.LoadXml(xml);
            CustomSignResult signresult = new CustomSignResult();
            string encryptedjson = "";
            string requestbody = "";
            string username = ProdBinarySecurityToken;
            string password = ProdSecret;
            string authCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));

            // encrypt Invoice
            encryptedjson = EncryptInvoice(CompCSID, csrPrivatekey, doc);
            signresult = JsonConvert.DeserializeObject<CustomSignResult>(encryptedjson);
            if (!signresult.IsValid)
            {

                EncryptionResult encryptionresult = new EncryptionResult();
                encryptionresult.ErrorMessage = signresult.ErrorMessage;
                encryptionresult.Steps = signresult.Steps;
                ClearenceResponse clearenceresponse = new ClearenceResponse();
                clearenceresponse.IsValid = false;
                clearenceresponse.encryptionResults = encryptionresult;
                return JsonConvert.SerializeObject(clearenceresponse);
            }
            string signedXmlBase64 = signresult.SignedEInvoiceBase64;
            // encrypt Invoice

            //Generate Request body
            ReportRequestBody reportrequestbody = new ReportRequestBody();
            reportrequestbody.invoiceHash = signresult.Steps.Where(m => m.StepName == "Generate EInvoice Hash").FirstOrDefault().ResultedValue;
            reportrequestbody.uuid = UUID;
            reportrequestbody.invoice = signedXmlBase64;
            requestbody = JsonConvert.SerializeObject(reportrequestbody);
            //Generate Request body

            using (HttpClient client = new HttpClient())
            {

                client.BaseAddress = (new Uri(BaseURL));
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + authCredentials);
                client.DefaultRequestHeaders.Add("Accept-Version", "V2");
                client.DefaultRequestHeaders.Add("accept-language", language);
                //client.DefaultRequestHeaders.Add("Clearance-Status", Clearance_Status);
                StringContent content = new StringContent(requestbody, Encoding.UTF8, "application/json");
                HttpResponseMessage result = client.PostAsync(Apiendpoint, content).Result;
                string str2 = result.Content.ReadAsStringAsync().Result;
                if (result.IsSuccessStatusCode)
                {
                    var clearenceresponse = JsonConvert.DeserializeObject<ClearenceResponse>(str2);
                    clearenceresponse.IsValid = true;
                    clearenceresponse.QR = GetQRcode(clearenceresponse.clearedInvoice);
                    return JsonConvert.SerializeObject(clearenceresponse);
                }

                return str2;

            }
        }

    }
}
