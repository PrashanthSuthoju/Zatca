﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zatca.EInvoice.SDK.Contracts.Models;

namespace Zatca
{
    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
    public class ErrorMessage
    {
        public string type { get; set; }
        public string code { get; set; }
        public string category { get; set; }
        public string message { get; set; }
        public string status { get; set; }
    }

    public class InfoMessage
    {
        public string type { get; set; }
        public string code { get; set; }
        public string category { get; set; }
        public string message { get; set; }
        public string status { get; set; }
    }
    public class WarningMessage
    {
        public string type { get; set; }
        public string code { get; set; }
        public string category { get; set; }
        public string message { get; set; }
        public string status { get; set; }
    }
    public class ValidationResults
    {
        public List<InfoMessage> infoMessages { get; set; }
        public List<WarningMessage> warningMessages { get; set; }
        public List<ErrorMessage> errorMessages { get; set; }
        public string status { get; set; }
    }
    public class EncryptionResult
    {
        public string ErrorMessage { get; set; }
        public List<StepResult> Steps { get; set; } = new List<StepResult>();
    }

    public class ClearenceResponse
    {
        public ValidationResults validationResults { get; set; }
        public string clearanceStatus { get; set; }
        public string clearedInvoice { get; set; }
        public string reportingStatus { get; set; }
        public string qrSellertStatus { get; set; }
        public string qrBuyertStatus { get; set; }
        public string QR { get; set; }
        public bool IsValid { get; set; }
        public EncryptionResult encryptionResults { get; set; }

    }






}
