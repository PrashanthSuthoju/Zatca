﻿namespace Zatca
{
    public class ReportRequestBody
    {
        public string invoiceHash { get; set; }
        public string uuid { get; set; }
        public string invoice { get; set; }
    }
}
